import '@/ai/flows/generate-word-puzzle.ts';
import '@/ai/flows/generate-eco-situation.ts';
import '@/ai/flows/carbon-emission-suggestions.ts';
import '@/ai/flows/generate-carbon-quiz.ts';
import '@/ai/flows/generate-eco-story.ts';
import '@/ai/test-azure.ts';
