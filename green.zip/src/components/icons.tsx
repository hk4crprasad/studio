import { Leaf } from 'lucide-react';

export const Icons = {
  logo: Leaf,
};
